<?php return array (
  'dashboard' => 'App\\Http\\Livewire\\Dashboard',
  'reports' => 'App\\Http\\Livewire\\Reports',
);