@extends('layouts.base')

@section('title')
    Dashboard
@endsection

@section('content')
 @livewireStyles
    <livewire:dashboard />
 @livewireScripts
@endsection
