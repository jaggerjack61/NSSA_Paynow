@extends('layouts.base')

@section('title')
    Reports
@endsection

@section('content')
    @livewireStyles
    <livewire:reports />
    @livewireScripts
@endsection
